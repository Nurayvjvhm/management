package kg.alatoo.entryapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntryApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntryApiApplication.class, args);
	}

}
