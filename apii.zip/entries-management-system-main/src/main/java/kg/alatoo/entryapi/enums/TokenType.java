package kg.alatoo.entryapi.enums;

public enum TokenType {
    VERIFICATION,
    PASSWORD_RESET
}
