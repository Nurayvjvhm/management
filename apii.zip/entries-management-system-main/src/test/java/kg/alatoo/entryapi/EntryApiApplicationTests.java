package kg.alatoo.entryapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntryApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
